MYRIX - GitHub APK build

IMPORTANT: Upload the CONTENTS of this ZIP to the ROOT of your GitHub repository.
Do not upload the outer folder MYRIX_Android as one nested folder.

The repository root should show:
- .github/workflows/build-apk.yml
- app/
- build.gradle
- gradle.properties
- settings.gradle

On GitHub:
1. Open your repository > Code.
2. Upload the extracted contents listed above to the repository root, or replace the current repository files with these.
3. Commit to branch main (or master).
4. Open Actions > Build MYRIX APK.
5. Wait for green check, then download MYRIX-debug-APK under Artifacts.
6. Extract the downloaded ZIP to get app-debug.apk.

This workflow builds a debug APK; it does not sign a Play Store release APK.
