MYRIX Android project + GitHub Actions build

Build APK using GitHub from an Android phone:
1. Extract this ZIP on your phone.
2. In GitHub, create a new repository (e.g. MYRIX), preferably private if you don't want to publish the source.
3. Upload the CONTENTS of the MYRIX_Android folder to the repository root. Make sure .github/workflows/build-apk.yml is uploaded too. On GitHub mobile, enabling "Desktop site" can make file uploads easier; alternatively use github.dev or upload the ZIP then extract it locally before uploading files.
4. Open the repository's Actions tab and select "Build MYRIX APK". If asked, enable GitHub Actions.
5. Tap "Run workflow" (or push to main/master to trigger automatically) and wait for the job to finish green.
6. Open the successful workflow run, scroll to Artifacts, and download "MYRIX-debug-APK". Extract it; the file is app-debug.apk.
7. Open the APK on your phone and allow installation from that source if Android asks.

Important:
- This is a source project, not a prebuilt APK.
- The workflow builds a DEBUG APK, not a Play Store release. It is unsigned for release distribution and intended for testing/installing locally.
- If the build fails, open the failed job and copy the first red error section to ChatGPT for diagnosis.
- The editor is bundled in app/src/main/assets/index.html. The workflow builds it into the Android WebView wrapper.
- Internet may be needed for CDN-backed export features.
